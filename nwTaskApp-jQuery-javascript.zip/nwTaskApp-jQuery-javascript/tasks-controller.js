// JavaScript source code
//function closureObject(){
//    var i = 0;
//    return {
//       addone: function () {
//            return ++i;
//        }
//    };
//};

    
tasksController = function () {

    var rowCount;
    var $taskPage;
    var initialised = false;
    var complete = document.createElement("VAR");
    function errorLogger(errorCode, errorMessage) {
        console.log(errorCode + ':' + errorMessage);
    } /* all the tasksController methods call
storageEngine methods which all require an
error callback as a parameter we code it just
once as a private function/method of
tasksController. */

    return {
        init: function (page, callback) {// nested callbacks required because javascript is asyncrinious 
            if (initialised) {
                callback();
            }
           else  {
                $taskPage = page;
                $taskPage.find('#importFile').change(loadFromCSV);
                

                storageEngine.init(function () {// create link to indxeddb 
                    storageEngine.initObjectStore('task', function () { callback(); }, errorLogger /*callback to call taskscontroller.loadtasks*/);// create the databfase
                }, errorLogger);


                $taskPage.find($('#btnAddTask')).click(function (evt) {
                    evt.preventDefault();
                    $taskPage.find($('#taskCreation')).removeClass('not');

                });

                $taskPage.find('[required="required"]').prev('label').append('<span>*</span>')
                    .children('span').addClass('required');

                $taskPage.find($('#saveTask')).click(function (evt) {
                    evt.preventDefault();
                    if ($taskPage.find('form').valid()) {
                        var task = $taskPage.find($('form')).toObject();
                        task.complete = false;
                        storageEngine.save("task", task,
                            function (savedTask) {
                                $taskPage.find('#tblTasks tbody').empty();// clear all the rows
                                tasksController.loadTasks();//refresh table memory (including edited task)
                                //$(':input').val('');// clear form fields
                                clearTask();
                                $taskPage.find('#taskCreation').addClass('not');
                                
                            }, errorLogger);
                    }
                });

                $taskPage.find('#clearTask').click(function (evt) {
                    evt.preventDefault();
                    clearTask();
                });

                $taskPage.find($("#taskForm")).validate({
                    rules: {
                        task: {

                            required: true,
                            maxlength: 20
                        },
                        messages: {
                            required: 'No we need it :('
                        }
                    }
                });

                $taskPage.find($('tbody')).on('click', 'td', 'time', function (evt) {
                    $(evt.target).closest('td').siblings().andSelf().toggleClass('rowHighlight');

                });// what is event.target??

                $taskPage.find($('#btnSelectAll')).click(function () {
                    var highlighted = $taskPage.find($("#tblTasks tbody tr td.rowHighlight"));
                    var AllRows = $taskPage.find($("#tblTasks tbody"))
                    console.log(highlighted);
                    $.each(highlighted, function (i, v) {
                        $(v).removeClass('rowHighlight')
                    });

                    $taskPage.find($('#tblTasks tbody tr td')).toggleClass('rowHighlight');



                });

                $taskPage.find($('#btnDeselectAll')).click(function () {
                    var highlighted = $taskPage.find($('#tblTasks tbody tr td.rowHighlight'))
                    $.each(highlighted, function (i, v) {
                        $(v).removeClass('rowHighlight');
                    })

                });


                $taskPage.find('#tblTasks tbody').on('click', '.deleteRow', function (evt) {
                    evt.preventDefault();
                    storageEngine.delete('task', $(evt.target).data().taskId, function () {
                        $(evt.target).parents('tr').remove();
                        rowCount--;
                        updateTaskCount();
                        bandTableRows();
                    }, errorLogger);



                });

                $taskPage.find('#tblTasks tbody').on('click', '.editRow', function (evt) {
                    evt.preventDefault();
                    $taskPage.find('#taskCreation').removeClass('not');
                    storageEngine.findById('task', $(evt.target).data().taskId,
                    function (task) {
                        $taskPage.find('form').fromObject(task);
                    }, errorLogger)

                });

                $taskPage.find('#tblTasks tbody').on('click', '.completeRow', function (evt) {
                    storageEngine.findById('task', $(evt.target).data().taskId, function (task) {
                                             task.complete = true;
                        storageEngine.save('task', task, function () {
                            tasksController.loadTasks();
                        }, errorLogger)

                    })

                });



                $taskPage.find($('#btnDeleteSelected')).click(function (evt) {
                    evt.preventDefault();
                    var RowSelected = $taskPage.find($("#tblTasks tbody tr:has(.rowHighlight)"));
                    var NoSelected = RowSelected.length;
                    var id
                    var numOfDeleted = 0
                    if (NoSelected > 0) {
                        var userChoice = confirm("Delete " + NoSelected + " selected tasks. Are you sure?")
                        if (userChoice) {

                            $.each(RowSelected, function (i, v) {
                                id =$(v).find('[data-task-id]').data().taskId;
                                storageEngine.delete('task', id,
                                function () {                                    
                                    numOfDeleted++;
                                    
                                    $(v).remove();
                                    
                                    if (numOfDeleted === NoSelected) {
                                        rowCount = rowCount - numOfDeleted;
                                        RowSelected.remove();                                        
                                        alert(NoSelected + " rows deleted.");
                                        
                                        updateTaskCount();
                                        bandTableRows();
                                    
                                        
                                    }
                                },   errorLogger);

                            })

                            
                        }
                       
                    }
                    else { alert("Delete cancelled.") };
                });

                initialised = true;


           


            };




        },


        loadTasks: function () {
            rowCount = 0
            $taskPage.find('#tblTasks tbody').empty();// clear all the rows
            storageEngine.findAll('task', function (tasks) {
                //finds all tasks in data storage and loads them into the tasks array 
                tasks.sort(function (task1, task2) {
                    var date1, date2;
                    date1 = Date.parse(task1.requiredBy);
                    date2 = Date.parse(task2.requiredBy);

                    return date1.compareTo(date2);
                });

                $.each(tasks, function (index, task) {
                    rowCount++
                    $('#taskRow').tmpl(task).appendTo($taskPage.find('#tblTasks tbody'));
                    //The jQuery.tmpl() method is designed for chaining with .appendTo, .prependTo, .insertAfter or .insertBefore 
                    updateTaskCount();
                    bandTableRows();
                    
                });
            }, errorLogger);

    }

    }

    function updateTaskCount() {
        $("footer").find("#tasksCounter").text(rowCount);
    }
 
    function clearTask() {
        $taskPage.find("form").fromObject({});
    }

    function bandTableRows() {
        $taskPage.find('#tblTasks tbody tr').removeClass('even');
        $taskPage.find('#tblTasks tbody tr:even').addClass('even');
                  overdueAndWarningBands();
    }

    function overdueAndWarningBands() {
        $.each($taskPage.find('#tblTasks tbody tr'), function (index, row) {
            var $row = $(row)
            var dueDate = Date.parse($row.find("[datetime]").text());
            
            if (dueDate.compareTo(Date.today()) < 0) {
                $row.removeClass('even');
                $row.addClass('overdue');
            }
            else if (dueDate.compareTo((2).days().fromNow()) <= 0) {
                $row.removeClass('even');
                $row.addClass('warning');
            }
        });


    }

   function loadFromCSV(event) {
        var reader = new FileReader(); 
        reader.onload = function (evt) { // need to prepare onload for reader
           
            var fileContents = evt.target.result;
            var tasks = []//

            var worker = new Worker('tasks-csvparser.js');// create a new thread/child thread
           // then consturct the listener on the backend and then the listen on the front end
            worker.addEventListener('message', function (result) {
                tasks = result.data

                storageEngine.saveAll('task', tasks, function () {
                    tasksController.loadTasks();
                }, errorLogger)

            }, false);

            worker.postMessage(fileContents);
        };

      
        reader.readAsText(event.target.files[0]); // the files[0] will store the current loaded file.
       // get the file and if any error occurs the onerror will be called
   }





}();// execute as soon as it is opened in the browser