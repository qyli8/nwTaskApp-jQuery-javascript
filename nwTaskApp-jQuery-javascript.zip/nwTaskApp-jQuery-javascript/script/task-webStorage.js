// JavaScript source code
storageEngine = function () {
    var initialized = false;
    var initializedObjectStores = {};
    function getStorageObject(type) {

        var item = localStorage.getItem(type);
        var parsedItem = JSON.parse(item);
        return parsedItem;

    };
    return {
        init: function (successCallback, errorCallback) {
            if (window.localStorage) {// test if browser supports web storage
                initialized = true; // will code all storageEngine methods so that they will 
                //only  if the private flag variable �initialized� has been 
                //set true
                successCallback(null);
            }
            else {
                errorCallback('storage_api_not_supported', 'The web storage api is not supported');
            }// how does this work??
        },

        initObjectStore: function (type, successCallback, errorCallback) {
            if (!initialized) {
                errorCallback('storage_api_not_initialized', 'The storage engine has not yet been initialized');
            }
            else if (!localStorage.getItem(type)) {// check to see if the specified array of objects exist
                localStorage.setItem(type, JSON.stringify({})); //If the object store container passed in does not with the id/key (i.e. type) passed in does not exist make a new empty one ({})
                initializedObjectStores[type] = true; // what is the purpose of this line???
                successCallback(null);
            }
            else if (localStorage.getItem(type)) {
                initializedObjectStores[type] = true;
                successCallback(null);

            }
        },
        save: function (type, obj, successCallback, errorCallback) {
            if (!initialized)
                errorCallback('storage_api_not_initialized', 'The storage engine has not been initilaized')
            else if (!initializedObjectStores[type])
                errorCallback('store_not_initalized', 'The object store' + type + ' has not been initialized')
            else {
                if (!obj.id)// if no key
                    obj.id = $.now();
                var storageItem = getStorageObject(type);
                storageItem[obj.id] = obj;
                localStorage.setItem(type, JSON.stringify(storageItem));
                successCallback(obj);
            }
        },

        findAll: function (type, successCallback, errorCallback) {
            if (!initialized)
                errorCallback('store_not_initialized', 'The storage engine has not been initialized');
            else if (!initializedObjectStores[type])
                errorCallback('store_not_initialized', '2.The object store' + type + ' has not been initialized');
            else {
                var result = [];
                var storageItem = getStorageObject(type);
                $.each(storageItem, function (i, v) {// need to make sure how this work??
                    result.push(v);
                });
                successCallback(result);
            }
        },

        delete: function (type, id, successCallback, errorCallback) {
            if (!initialized)
                errorCallback('storage_api_not_intialized', 'The storage engine has not been initialized');// check to see if storage engine is initialised
            else if (!initializedObjectStores[type])
                errorCallback('store_not_initialized', '2.object store' + type + ' has not been initialized')// check to see if the specified object in the local storage exist
            else {
                var storageItem = getStorageObject(type);// store the array of objects from the local storage as a JS objects
                if (storageItem[id]) {// check if the object exist in the array
                    delete storageItem[id]; // JS syntax to delete a property of an object
                    localStorage.setItem(type, JSON.stringify(storageItem));// put store back 1 task lighter??? replace the old array in the local storage with the updated array? 
                    successCallback(id); // where will the id be used??
                }
                else
                    errorCallback("object_not_found", "the object to be deleted could not be found");

            }

        },

        findByProperty: function (type, propertyName, propertyValue, successCallback, errorCallback) {
            if (!initialized)
                errorCallback('storage_api_not_intialized', 'The storage engine has not been initialized');// check to see if the storage engine is initialised
            else if (!initializedObjectStores[type])
                errorCallback('store_not_initialized', '2.object store' + type + ' has not been initialized')// check to see if the sepcified object in the local storage exist
            else {
                var result = [];// create an empty array
                var storageItem = getStorageObject(type); // get the array of objects in the local storage and store as JS objects
                $.each(storageItem, function (i, v) { 
                    if (v[propertyName] === propertyValue) // loop through each object in the array to find the mataching property and store in the array called result
                        result.push(v);
                });
                successCallback(result);
            }

        },
        findById: function (type, id, successCallback, errorCallback) {// need make sure how the whole findById function work??
            if (!initialized)
                errorCallback('storage_api_not_intialized', 'The storage engine has not been initialized'); //  check to see if the storage engine is initialised
            else if (!initializedObjectStores[type])
                errorCallback('store_not_initialized', '2.object store' + type + ' has not been initialized') //check to see if the sepcified object in the local storage exist
            else {
                var storageItem = getStorageObject(type); // get the array of objects in the local storage and store as JS objects
                var result = storageItem[id]; // store the object with matching id to result
                if (!result) // check to see if the result is null
                    result = null;
                successCallback(result); 
            }
        },

        saveAll: function (type, objArray, successCallback, errorCallback) {
            if (!initialized)
                errorCallback('storage_api_not_initialized', 'The storage engine has not been initialized');
            else if(!initializedObjectStores[type])
                errorCallback('store_not_initialized', '1.object store' + type + ' has not been initialized')
            else {
                var storageItem = getStorageObject(type)
                $.each(objArray, function (i, obj) {
                    if (!obj.id)
                        obj.id = $.now();
                    storageItem[obj.id] = obj;
                    localStorage.setItem(type, JSON.stringify(storageItem));

                });
                successCallback(objArray);
            }
        }

  


    };

}();

