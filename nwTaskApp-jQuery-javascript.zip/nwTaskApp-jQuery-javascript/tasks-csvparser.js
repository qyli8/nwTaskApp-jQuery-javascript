//debugger;

self.addEventListener('message', function (aMassage) {
    var data = aMassage.data;
    var lines = data.split('\n');
    var tasks = [];

    for (var i = 0; i < lines.length; i++) {
        var val = lines[i];
        if (i >= 1 && val) {
            var task = loadTask(val);
            if (task)
                tasks.push(task);
        }
    }    
    self.postMessage(tasks);// send message back to the controller
}, false);

function loadTask(csvTask) {
    var tokens = csvTask.split(',');
    debugger;
    if (tokens.length === 5) {
        var task = {};
        task.task = tokens[0];
        task.requiredBy = tokens[1];;
        task.category = tokens[2];
        task.doneFor = tokens[3]
        task.complete = tokens[4];
        return task;
    }
    else
        return null;
}